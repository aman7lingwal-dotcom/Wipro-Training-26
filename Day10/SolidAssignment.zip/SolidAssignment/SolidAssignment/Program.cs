﻿using SolidAssignment.Interfaces;
using SolidAssignment.Services;
using SolidAssignment.Formatters;
using SolidAssignment.Patterns;

namespace SolidAssignment;

class Program
{
    static void Main(string[] args)
    {
        IReportGenerator generator = new ReportGenerator();
        IReportSaver saver = new ReportSaver();
        IReportFormatter formatter = new PdfFormatter();

        var reportService = new ReportService(generator, saver, formatter);
        reportService.ProcessReport();

        var doc = DocumentFactory.Create("PDF");
        doc.Open();

        Console.ReadLine();
    }
}