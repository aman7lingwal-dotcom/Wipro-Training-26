﻿using SolidAssignment.Interfaces;

namespace SolidAssignment.Services;

public class ReportSaver : IReportSaver
{
    public void Save(string content)
    {
        File.WriteAllText("report.txt", content);
        Console.WriteLine("Report saved successfully.");
    }
}
