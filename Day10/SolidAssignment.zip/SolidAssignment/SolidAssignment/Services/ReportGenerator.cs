﻿using SolidAssignment.Interfaces;

namespace SolidAssignment.Services;

public class ReportGenerator : IReportGenerator
{
    public string Generate()
    {
        return "Generated Report Content";
    }
}