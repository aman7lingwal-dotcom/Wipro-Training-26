﻿namespace SolidAssignment.Patterns;

public interface IDocument
{
    void Open();
}

public class PdfDocument : IDocument
{
    public void Open()
    {
        Console.WriteLine("Opening PDF Document");
    }
}

public class WordDocument : IDocument
{
    public void Open()
    {
        Console.WriteLine("Opening Word Document");
    }
}

public class DocumentFactory
{
    public static IDocument Create(string type)
    {
        return type switch
        {
            "PDF" => new PdfDocument(),
            "WORD" => new WordDocument(),
            _ => throw new ArgumentException("Invalid type")
        };
    }
}