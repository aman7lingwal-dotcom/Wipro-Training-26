﻿namespace SolidAssignment.Interfaces;

public interface IReportFormatter
{
    string Format(string content);
}
