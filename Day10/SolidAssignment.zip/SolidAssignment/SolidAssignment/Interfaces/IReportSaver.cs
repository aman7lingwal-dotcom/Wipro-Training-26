﻿namespace SolidAssignment.Interfaces;

public interface IReportSaver
{
    void Save(string content);
}
