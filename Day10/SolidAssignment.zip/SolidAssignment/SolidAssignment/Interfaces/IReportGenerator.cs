﻿namespace SolidAssignment.Interfaces;

public interface IReportGenerator
{
    string Generate();
}