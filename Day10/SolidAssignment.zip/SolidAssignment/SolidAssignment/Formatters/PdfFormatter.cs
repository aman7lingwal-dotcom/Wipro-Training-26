﻿using SolidAssignment.Interfaces;

namespace SolidAssignment.Formatters;

public class PdfFormatter : IReportFormatter
{
    public string Format(string content)
    {
        return $"PDF Format: {content}";
    }
}